<h3>Halo Dokter {{ $patient->doctor->nama }},</h3>
<p>Ada pasien baru bernama <strong>{{ $patient->nama }}</strong> yang perlu Anda verifikasi.</p>
<p>Silakan login ke sistem untuk melakukan verifikasi.</p>
