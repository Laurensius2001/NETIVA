<link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
<x-layout title="Home">
  <section id="beranda" style="scroll-margin-top: 100px;">
    <div class="gradient-bg container py-5">
      <div class="row align-items-center">
        <div class="col-12 col-md-6 text-start mb-4 mb-md-0">
          <h1 class="display-5 fw-bold text-primary">Selamat Datang di Sistem Deteksi Kanker Serviks Netiva</h1>
          <p class="lead mt-3">
            Ivanet memiliki tujuan untuk membuat dan mengembangkan aplikasi yang memudahkan tenaga medis dalam memeriksa dan memonitoring sebaran kanker serviks..
          </p>
          <a href="{{ route('login') }}" class="btn btn-primary btn-lg mt-3">Mulai Sekarang</a>
        </div>
        <div class="col-12 col-md-6 text-center">
          <img src="{{ asset('images/undraw_doctor.svg') }}" alt="Ilustrasi Dokter" class="img-fluid" style="max-height: 400px;">
        </div>
      </div>
    </div>
  </section>

  <section id="tentang" class="py-5 px-3 px-md-5 bg-white" style="scroll-margin-top: 100px;">
    <div class="container">
      <h2 class="text-center mb-4 fw-bold">Tentang Ivanet</h2>
      <p class="text-center lead">
        Ivanet adalah sebuah riset terkait dengan kanker serviks. Berikut adalah tujuan dari Ivanet.
      </p>
      <div class="row mt-4">
        <div class="col-md-6 mb-4">
          <h5 class="fw-bold lead">Deteksi Pra Kanker Serviks</h5>
          <p class="lead">
            Deteksi pra kanker serviks dapat dilakukan menggunakan Ivanet Apps. Deteksi dilakukan pada SSK
            (sambungan skuamo kolumnar) & tes IVA (Inspeksi Visual dengan Asam Asetat).
          </p>
        </div>
        <div class="col-md-6 mb-4">
          <h5 class="fw-bold">Memetakan Sebaran Hasil Tes IVA</h5>
          <p class="lead">
            Ivanet juga menyediakan website untuk melihat sebaran hasil tes IVA yang dikategorikan berdasarkan kecamatan.
            Data dapat dilihat dengan format Peta, Tabel & Grafik.
          </p>
        </div>
      </div>
    </div>
  </section>

  <section id="maps" class="py-5" style="scroll-margin-top: 100px;">
    <div class="col-md-8">
      <div class="px-2 py-2 bg-light rounded-3">
        <h5 class="text-center fw-bold mb-3">Peta Persebaran Kasus Kanker Serviks (Wilayah Jawa Barat)</h5>
        <div id="map" style="height: 690px;"></div>
      </div>
    </div>
  </section>

  <script>
    const map = L.map('map').setView([-6.9, 107.6], 8);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    const dataKabupaten = {
      "BANDUNG": 56,
      "BANDUNG BARAT": 34,
      "BANJAR": 12,
      "BEKASI": 70,
      "BOGOR": 63,
      "CIAMIS": 28,
      "CIANJUR": 39,
      "CIREBON": 31,
      "DEPOK": 45,
      "GARUT": 50,
      "INDRAMAYU": 42,
      "KARAWANG": 36,
      "KOTA BANDUNG": 48,
      "KOTA BEKASI": 40,
      "KOTA BOGOR": 33,
      "KOTA CIMAHI": 21,
      "KOTA CIREBON": 25,
      "KOTA DEPOK": 38,
      "KOTA SUKABUMI": 17,
      "KOTA TASIKMALAYA": 22,
      "KUNINGAN": 27,
      "MAJALENGKA": 19,
      "PANGANDARAN": 15,
      "PURWAKARTA": 18,
      "SUBANG": 26,
      "SUKABUMI": 35,
      "SUMEDANG": 24,
      "TASIKMALAYA": 29
    };
    function getColor(jumlah) {
      return jumlah > 60 ? '#800026' :
            jumlah > 40 ? '#BD0026' :
            jumlah > 30 ? '#E31A1C' :
            jumlah > 20 ? '#FC4E2A' :
            jumlah > 10 ? '#FD8D3C' :
            jumlah > 0  ? '#FEB24C' :
                          '#FFEDA0';
    }
    function style(feature) {
      const nama = (feature.properties.KABKOT || '').trim();
      const jumlah = dataKabupaten[nama] || 0;
      return {
        fillColor: getColor(jumlah),
        weight: 1,
        opacity: 1,
        color: 'white',
        dashArray: '3',
        fillOpacity: 0.7
      };
    }

    function onEachFeature(feature, layer) {
      const nama = (feature.properties.KABKOT || '-').trim();
      const jumlah = dataKabupaten[nama] || 0;
      layer.bindPopup(`<strong>${nama}</strong><br>${jumlah} kasus kanker serviks`);

      layer.on({
        mouseover: function (e) {
          e.target.setStyle({
            weight: 3,
            color: '#666',
            fillOpacity: 0.9
          });
          e.target.openPopup();
        },
        mouseout: function (e) {
          geojson.resetStyle(e.target);
          e.target.closePopup();
        },
        click: function (e) {
          map.fitBounds(e.target.getBounds());
        }
      });
    }

    let geojson;

    fetch('/maps/jabar_kabupaten.geojson')
      .then(res => res.json())
      .then(data => {
        geojson = L.geoJson(data, {
          style: style,
          onEachFeature: onEachFeature
        }).addTo(map);
      })
      .catch(err => console.error("Gagal memuat GeoJSON:", err));
</script>
</x-layout>
<section id="kontak" style="scroll-margin-top: 100px;">
  <footer class="bg-dark text-white py-4 w-100">
    <div class="container text-center">
      <a class="navbar-brand d-inline-block mb-3" href="/">
        <img src="{{ asset('images/logo.png') }}" alt="Netiva" height="30" style="filter: brightness(0) invert(1);">
      </a>
      <p class="mb-1">Jl. Telekomunikasi - Ters. Buah Batu Bandung 40257 Indonesia</p>
      <p class="mb-1">Telephone: (022) 7566456</p>
      <p class="mb-1">Email: info@ivanet.id</p>
      <hr class="bg-light" style="opacity: 0.3;">
      <p class="mb-0">&copy; 2020 Ivanet. All rights reserved.</p>
    </div>
  </footer>
</section>