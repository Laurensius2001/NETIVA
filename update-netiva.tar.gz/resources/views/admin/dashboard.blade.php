<x-layout title="Dashboard Admin">
  <div class="container py-5 text-center">
    <h1 class="mb-4">Halo, Admin!</h1>
    <p>Selamat datang di dashboard admin. Anda bisa mengelola data dokter, pasien, dan citra.</p>
  </div>
</x-layout>
